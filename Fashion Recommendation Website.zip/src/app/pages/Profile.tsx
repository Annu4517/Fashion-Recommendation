import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Navbar } from '../components/Navbar';
import { AvatarDisplay } from '../components/AvatarDisplay';
import { Edit2, Mail, MapPin, Save, X, Heart } from 'lucide-react';

export default function Profile() {
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [location, setLocation] = useState('San Francisco, CA');
  const [bio, setBio] = useState('Fashion lover exploring new styles every day! ✨');

  useEffect(() => {
    const savedName = localStorage.getItem('userName') || 'Style Enthusiast';
    const savedEmail = localStorage.getItem('userEmail') || 'hello@stylemusе.com';
    setName(savedName);
    setEmail(savedEmail);
  }, []);

  const handleSave = () => {
    localStorage.setItem('userName', name);
    localStorage.setItem('userEmail', email);
    setIsEditing(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-lavender-50 via-cream-50 to-peach-50">
      <Navbar />

      <div className="pt-24 pb-12 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
            <div className="h-48 bg-gradient-to-r from-peach-200 via-pink-200 to-lavender-200 relative overflow-hidden">
              <div className="absolute inset-0 opacity-30">
                <div className="absolute top-10 left-10 w-20 h-20 bg-white rounded-full"></div>
                <div className="absolute top-32 right-20 w-16 h-16 bg-white rounded-full"></div>
                <div className="absolute bottom-10 left-1/3 w-24 h-24 bg-white rounded-full"></div>
              </div>
            </div>

            <div className="px-8 pb-8">
              <div className="flex flex-col items-center -mt-24 mb-8">
                <div className="bg-white p-4 rounded-full shadow-2xl mb-4">
                  <AvatarDisplay size="large" showInfo={false} />
                </div>

                <h2 className="text-3xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>
                  {name}
                </h2>
                <p className="text-gray-600 mb-4" style={{ fontFamily: 'Inter, sans-serif' }}>
                  {email}
                </p>

                <button
                  onClick={() => navigate('/avatar-selection')}
                  className="px-6 py-2 bg-gradient-to-r from-peach-200 to-pink-200 text-gray-800 rounded-full font-medium hover:shadow-md hover:scale-105 active:scale-95 transition-all"
                  style={{ fontFamily: 'Poppins, sans-serif' }}
                >
                  Change Avatar
                </button>
              </div>

              <div className="max-w-2xl mx-auto">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-2xl font-bold text-gray-900" style={{ fontFamily: 'Poppins, sans-serif' }}>
                    Profile Details
                  </h3>
                  {isEditing ? (
                    <div className="flex gap-2">
                      <button
                        onClick={handleSave}
                        className="flex items-center gap-2 px-4 py-2 bg-peach-300 text-white rounded-full hover:bg-peach-400 transition-all"
                        style={{ fontFamily: 'Poppins, sans-serif' }}
                      >
                        <Save className="w-4 h-4" />
                        Save
                      </button>
                      <button
                        onClick={() => setIsEditing(false)}
                        className="flex items-center gap-2 px-4 py-2 bg-gray-200 text-gray-700 rounded-full hover:bg-gray-300 transition-all"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setIsEditing(true)}
                      className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200 transition-all"
                      style={{ fontFamily: 'Poppins, sans-serif' }}
                    >
                      <Edit2 className="w-4 h-4" />
                      Edit
                    </button>
                  )}
                </div>

                <div className="space-y-6">
                  <div className="bg-gray-50 rounded-2xl p-5">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-peach-100 rounded-2xl flex items-center justify-center flex-shrink-0">
                        <Heart className="w-5 h-5 text-peach-400" />
                      </div>
                      <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-600 mb-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                          Full Name
                        </label>
                        {isEditing ? (
                          <input
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="w-full px-4 py-2 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-peach-300"
                            style={{ fontFamily: 'Poppins, sans-serif' }}
                          />
                        ) : (
                          <p className="text-lg text-gray-900" style={{ fontFamily: 'Poppins, sans-serif' }}>{name}</p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-2xl p-5">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-pink-100 rounded-2xl flex items-center justify-center flex-shrink-0">
                        <Mail className="w-5 h-5 text-pink-400" />
                      </div>
                      <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-600 mb-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                          Email Address
                        </label>
                        {isEditing ? (
                          <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full px-4 py-2 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-300"
                            style={{ fontFamily: 'Poppins, sans-serif' }}
                          />
                        ) : (
                          <p className="text-lg text-gray-900" style={{ fontFamily: 'Poppins, sans-serif' }}>{email}</p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-2xl p-5">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-lavender-100 rounded-2xl flex items-center justify-center flex-shrink-0">
                        <MapPin className="w-5 h-5 text-lavender-300" />
                      </div>
                      <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-600 mb-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                          Location
                        </label>
                        {isEditing ? (
                          <input
                            type="text"
                            value={location}
                            onChange={(e) => setLocation(e.target.value)}
                            className="w-full px-4 py-2 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-lavender-300"
                            style={{ fontFamily: 'Poppins, sans-serif' }}
                          />
                        ) : (
                          <p className="text-lg text-gray-900" style={{ fontFamily: 'Poppins, sans-serif' }}>{location}</p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-2xl p-5">
                    <label className="block text-sm font-medium text-gray-600 mb-3" style={{ fontFamily: 'Inter, sans-serif' }}>
                      Bio
                    </label>
                    {isEditing ? (
                      <textarea
                        value={bio}
                        onChange={(e) => setBio(e.target.value)}
                        rows={4}
                        className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-peach-300"
                        style={{ fontFamily: 'Poppins, sans-serif' }}
                      />
                    ) : (
                      <p className="text-gray-700 leading-relaxed" style={{ fontFamily: 'Poppins, sans-serif' }}>{bio}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
