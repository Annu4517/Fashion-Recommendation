import { Navbar } from '../components/Navbar';
import { Sparkles, Heart, Palette, Users } from 'lucide-react';

export default function About() {
  const features = [
    {
      icon: Sparkles,
      title: 'Smart Recommendations',
      description: 'Get personalized outfit suggestions based on your unique style avatar and preferences.',
      gradient: 'from-peach-200 to-pink-200'
    },
    {
      icon: Heart,
      title: 'Style Avatars',
      description: 'Express yourself through beautiful avatars that match your fashion personality.',
      gradient: 'from-pink-200 to-lavender-200'
    },
    {
      icon: Palette,
      title: 'Curated Looks',
      description: 'Discover handpicked outfit combinations for every occasion and mood.',
      gradient: 'from-lavender-200 to-peach-200'
    },
    {
      icon: Users,
      title: 'Fashion Community',
      description: 'Join a community of style enthusiasts sharing their favorite looks.',
      gradient: 'from-peach-300 to-pink-300'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-peach-50 via-cream-50 to-lavender-50">
      <Navbar />

      <div className="pt-24 pb-12 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-peach-200 to-pink-200 rounded-full mb-6 shadow-lg">
              <Heart className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-6xl font-bold text-gray-900 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
              About StyleMuse
            </h1>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: 'Inter, sans-serif' }}>
              Your personal fashion companion that helps you discover and express your unique style.
              We believe fashion should be fun, accessible, and inspiring for everyone. ✨
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <div
                  key={idx}
                  className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
                >
                  <div className={`w-16 h-16 bg-gradient-to-r ${feature.gradient} rounded-2xl flex items-center justify-center mb-6 shadow-md`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-3" style={{ fontFamily: 'Poppins, sans-serif' }}>
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed" style={{ fontFamily: 'Inter, sans-serif' }}>
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>

          <div className="bg-white rounded-3xl p-12 shadow-xl border border-gray-100">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-4xl font-bold text-gray-900 mb-6 text-center" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Our Story
              </h2>
              <div className="space-y-4 text-gray-700 leading-relaxed" style={{ fontFamily: 'Inter, sans-serif' }}>
                <p>
                  StyleMuse was born from a simple idea: fashion recommendations should be personal,
                  visual, and fun. We wanted to create a space where you can explore different styles
                  through avatars that truly represent your fashion personality.
                </p>
                <p>
                  Whether you're looking for casual everyday looks, professional office attire,
                  glamorous party outfits, or minimalist aesthetic pieces, StyleMuse helps you
                  discover what makes you feel confident and beautiful.
                </p>
                <p>
                  We're not just another fashion app—we're your style companion, helping you
                  express yourself authentically through curated outfit recommendations tailored
                  to your unique taste.
                </p>
              </div>

              <div className="mt-10 pt-8 border-t border-gray-200">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
                  <div>
                    <div className="text-4xl font-bold text-peach-400 mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                      10K+
                    </div>
                    <p className="text-gray-600 text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
                      Happy Users
                    </p>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-pink-400 mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                      50K+
                    </div>
                    <p className="text-gray-600 text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
                      Outfit Ideas
                    </p>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-lavender-300 mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                      4
                    </div>
                    <p className="text-gray-600 text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
                      Style Avatars
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-8 text-center">
                <p className="text-gray-500 text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
                  Made with love for fashion lovers worldwide 💕
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
