import { useNavigate } from 'react-router';
import { useAvatar, AvatarStyle } from '../context/AvatarContext';
import { avatarStyles } from '../data/avatarData';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { Check, Sparkles } from 'lucide-react';

export default function AvatarSelection() {
  const navigate = useNavigate();
  const { selectedAvatar, setSelectedAvatar } = useAvatar();

  const avatarOptions: AvatarStyle[] = ['casual', 'formal', 'party', 'minimal'];

  const handleContinue = () => {
    navigate('/home');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cream-50 via-peach-50 to-lavender-50 flex items-center justify-center p-6">
      <div className="max-w-5xl w-full">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-peach-400 animate-pulse" />
          </div>
          <h1 className="text-5xl font-bold text-gray-800 mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Choose Your Style Avatar
          </h1>
          <p className="text-gray-600 text-lg" style={{ fontFamily: 'Inter, sans-serif' }}>
            Pick the look that speaks to you ✨
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {avatarOptions.map((style) => {
            const avatarData = avatarStyles[style];
            const isSelected = selectedAvatar === style;

            return (
              <button
                key={style}
                onClick={() => setSelectedAvatar(style)}
                className={`group relative bg-white rounded-3xl p-6 transition-all duration-300 hover:scale-105 ${
                  isSelected
                    ? 'shadow-2xl ring-4'
                    : 'shadow-lg hover:shadow-xl'
                }`}
                style={{
                  ringColor: isSelected ? avatarData.color : 'transparent'
                }}
              >
                {isSelected && (
                  <div
                    className="absolute -top-3 -right-3 w-10 h-10 rounded-full flex items-center justify-center shadow-lg"
                    style={{ backgroundColor: avatarData.color }}
                  >
                    <Check className="w-5 h-5 text-white" />
                  </div>
                )}

                <div className="relative mb-4 overflow-hidden rounded-2xl shadow-md">
                  <ImageWithFallback
                    src={avatarData.image}
                    alt={avatarData.name}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  {isSelected && (
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                  )}
                </div>

                <div className="text-center space-y-2">
                  <h3 className="font-semibold text-lg text-gray-800" style={{ fontFamily: 'Poppins, sans-serif' }}>
                    {avatarData.name}
                  </h3>
                  <p className="text-sm text-gray-500" style={{ fontFamily: 'Inter, sans-serif' }}>
                    {avatarData.description}
                  </p>
                </div>

                <div
                  className={`mt-4 h-1 rounded-full transition-all duration-300 ${
                    isSelected ? 'opacity-100' : 'opacity-0'
                  }`}
                  style={{ backgroundColor: avatarData.color }}
                />
              </button>
            );
          })}
        </div>

        <div className="text-center">
          <button
            onClick={handleContinue}
            className="px-12 py-4 bg-gradient-to-r from-peach-300 to-pink-300 text-white rounded-full font-semibold shadow-lg hover:shadow-xl hover:scale-105 active:scale-95 transition-all duration-200 text-lg"
            style={{ fontFamily: 'Poppins, sans-serif' }}
          >
            Continue to StyleMuse
          </button>
        </div>
      </div>
    </div>
  );
}
