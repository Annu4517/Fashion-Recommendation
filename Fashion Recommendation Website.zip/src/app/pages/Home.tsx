import { useState } from 'react';
import { Navbar } from '../components/Navbar';
import { AvatarDisplay } from '../components/AvatarDisplay';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { outfitRecommendations } from '../data/avatarData';
import { Filter, Heart, Bookmark } from 'lucide-react';

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [likedOutfits, setLikedOutfits] = useState<Set<number>>(new Set());

  const filteredOutfits = selectedCategory === 'all'
    ? outfitRecommendations
    : outfitRecommendations.filter(outfit => outfit.category === selectedCategory);

  const toggleLike = (id: number) => {
    const newLiked = new Set(likedOutfits);
    if (newLiked.has(id)) {
      newLiked.delete(id);
    } else {
      newLiked.add(id);
    }
    setLikedOutfits(newLiked);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cream-50 via-peach-50 to-lavender-50">
      <Navbar />

      <div className="pt-24 pb-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <aside className="lg:col-span-3">
              <div className="sticky top-28 space-y-6">
                <div className="bg-white rounded-3xl p-6 shadow-lg border border-gray-100">
                  <h3 className="text-sm font-semibold text-gray-500 mb-4 uppercase tracking-wide" style={{ fontFamily: 'Inter, sans-serif' }}>
                    Your Style Avatar
                  </h3>
                  <AvatarDisplay size="large" />
                </div>

                <div className="bg-white rounded-3xl p-6 shadow-lg border border-gray-100">
                  <h4 className="font-semibold text-gray-800 mb-4 flex items-center gap-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                    <Filter className="w-4 h-4 text-peach-400" />
                    Filter Outfits
                  </h4>
                  <div className="space-y-2">
                    {['all', 'casual', 'formal', 'party', 'minimal'].map((category) => (
                      <button
                        key={category}
                        onClick={() => setSelectedCategory(category)}
                        className={`w-full px-4 py-2 rounded-xl text-left transition-all duration-200 ${
                          selectedCategory === category
                            ? 'bg-gradient-to-r from-peach-200 to-pink-200 text-gray-800 shadow-md'
                            : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                        }`}
                        style={{ fontFamily: 'Inter, sans-serif' }}
                      >
                        {category.charAt(0).toUpperCase() + category.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </aside>

            <main className="lg:col-span-9">
              <div className="mb-8">
                <h1 className="text-4xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                  Style Recommendations
                </h1>
                <p className="text-gray-600" style={{ fontFamily: 'Inter, sans-serif' }}>
                  Curated looks just for you ✨
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredOutfits.map((outfit) => (
                  <div
                    key={outfit.id}
                    className="group bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2"
                  >
                    <div className="relative h-72 overflow-hidden bg-gray-100">
                      <ImageWithFallback
                        src={outfit.image}
                        alt={outfit.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                      <div className="absolute top-3 right-3 flex gap-2">
                        <button
                          onClick={() => toggleLike(outfit.id)}
                          className={`w-10 h-10 backdrop-blur-md rounded-full flex items-center justify-center transition-all shadow-lg ${
                            likedOutfits.has(outfit.id)
                              ? 'bg-pink-400 text-white scale-110'
                              : 'bg-white/90 text-gray-700 hover:bg-pink-100'
                          }`}
                        >
                          <Heart className={`w-5 h-5 ${likedOutfits.has(outfit.id) ? 'fill-current' : ''}`} />
                        </button>
                        <button className="w-10 h-10 bg-white/90 backdrop-blur-md rounded-full flex items-center justify-center hover:bg-peach-100 transition-all shadow-lg">
                          <Bookmark className="w-5 h-5 text-gray-700" />
                        </button>
                      </div>
                    </div>

                    <div className="p-5">
                      <h3 className="font-semibold text-lg text-gray-900 mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                        {outfit.name}
                      </h3>
                      <p className="text-sm text-gray-600 mb-3" style={{ fontFamily: 'Inter, sans-serif' }}>
                        {outfit.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="px-3 py-1 bg-peach-100 text-peach-600 rounded-full text-xs font-medium">
                          {outfit.mood}
                        </span>
                        <span className="text-xs text-gray-500 capitalize">
                          {outfit.category}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}
