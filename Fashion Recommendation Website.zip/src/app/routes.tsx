import { createBrowserRouter } from 'react-router';
import Login from './pages/Login';
import Signup from './pages/Signup';
import AvatarSelection from './pages/AvatarSelection';
import Home from './pages/Home';
import Profile from './pages/Profile';
import About from './pages/About';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Login,
  },
  {
    path: '/signup',
    Component: Signup,
  },
  {
    path: '/avatar-selection',
    Component: AvatarSelection,
  },
  {
    path: '/home',
    Component: Home,
  },
  {
    path: '/profile',
    Component: Profile,
  },
  {
    path: '/about',
    Component: About,
  },
]);
