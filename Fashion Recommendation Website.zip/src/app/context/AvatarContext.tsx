import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type AvatarStyle = 'casual' | 'formal' | 'party' | 'minimal';

interface AvatarContextType {
  selectedAvatar: AvatarStyle;
  setSelectedAvatar: (style: AvatarStyle) => void;
}

const AvatarContext = createContext<AvatarContextType | undefined>(undefined);

export function AvatarProvider({ children }: { children: ReactNode }) {
  const [selectedAvatar, setSelectedAvatarState] = useState<AvatarStyle>(() => {
    const saved = localStorage.getItem('selectedAvatar');
    return (saved as AvatarStyle) || 'casual';
  });

  const setSelectedAvatar = (style: AvatarStyle) => {
    setSelectedAvatarState(style);
    localStorage.setItem('selectedAvatar', style);
  };

  useEffect(() => {
    localStorage.setItem('selectedAvatar', selectedAvatar);
  }, [selectedAvatar]);

  return (
    <AvatarContext.Provider value={{ selectedAvatar, setSelectedAvatar }}>
      {children}
    </AvatarContext.Provider>
  );
}

export function useAvatar() {
  const context = useContext(AvatarContext);
  if (!context) {
    throw new Error('useAvatar must be used within AvatarProvider');
  }
  return context;
}
