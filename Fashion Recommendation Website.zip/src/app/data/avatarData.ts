import { AvatarStyle } from '../context/AvatarContext';

export const avatarStyles: Record<AvatarStyle, {
  name: string;
  description: string;
  image: string;
  color: string;
}> = {
  casual: {
    name: 'Casual Look',
    description: 'Comfy & everyday style',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&h=400&fit=crop&crop=faces',
    color: '#FFD4A3'
  },
  formal: {
    name: 'Formal Look',
    description: 'Professional & elegant',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faces',
    color: '#B4A5C7'
  },
  party: {
    name: 'Party Look',
    description: 'Bold & glamorous',
    image: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=400&h=400&fit=crop&crop=faces',
    color: '#FFB6C1'
  },
  minimal: {
    name: 'Minimal Look',
    description: 'Simple & chic',
    image: 'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=400&h=400&fit=crop&crop=faces',
    color: '#E8D5C4'
  }
};

export const outfitRecommendations = [
  {
    id: 1,
    name: 'Cozy Sweater & Jeans',
    category: 'casual',
    image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=500&h=700&fit=crop',
    description: 'Perfect for coffee dates',
    mood: 'Relaxed'
  },
  {
    id: 2,
    name: 'Office Chic Blazer',
    category: 'formal',
    image: 'https://images.unsplash.com/photo-1591369822096-ffd140ec948f?w=500&h=700&fit=crop',
    description: 'Confidence in style',
    mood: 'Professional'
  },
  {
    id: 3,
    name: 'Sparkle Dress',
    category: 'party',
    image: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=500&h=700&fit=crop',
    description: 'Shine all night',
    mood: 'Glamorous'
  },
  {
    id: 4,
    name: 'White Tee & Beige Pants',
    category: 'minimal',
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=500&h=700&fit=crop',
    description: 'Less is more',
    mood: 'Elegant'
  },
  {
    id: 5,
    name: 'Denim Jacket Combo',
    category: 'casual',
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=500&h=700&fit=crop',
    description: 'Street style vibes',
    mood: 'Cool'
  },
  {
    id: 6,
    name: 'Tailored Suit',
    category: 'formal',
    image: 'https://images.unsplash.com/photo-1594938291221-94f18cbb5660?w=500&h=700&fit=crop',
    description: 'Power dressing',
    mood: 'Bold'
  },
  {
    id: 7,
    name: 'Sequin Top & Skirt',
    category: 'party',
    image: 'https://images.unsplash.com/photo-1539008835657-9e8e9680c956?w=500&h=700&fit=crop',
    description: 'Dance floor ready',
    mood: 'Fun'
  },
  {
    id: 8,
    name: 'Neutral Layers',
    category: 'minimal',
    image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=500&h=700&fit=crop',
    description: 'Timeless beauty',
    mood: 'Calm'
  },
  {
    id: 9,
    name: 'Graphic Tee & Sneakers',
    category: 'casual',
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=500&h=700&fit=crop',
    description: 'Effortlessly cool',
    mood: 'Playful'
  }
];
