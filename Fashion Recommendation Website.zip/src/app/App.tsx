import { RouterProvider } from 'react-router';
import { router } from './routes';
import { AvatarProvider } from './context/AvatarContext';

export default function App() {
  return (
    <AvatarProvider>
      <RouterProvider router={router} />
    </AvatarProvider>
  );
}