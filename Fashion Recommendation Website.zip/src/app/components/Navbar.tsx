import { Link, useLocation } from 'react-router';
import { Home, User, Info, Sparkles } from 'lucide-react';

export function Navbar() {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-lg shadow-sm">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link to="/home" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-gradient-to-br from-peach-300 to-pink-300 rounded-full flex items-center justify-center shadow-md group-hover:shadow-lg transition-all">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-2xl font-bold text-gray-800" style={{ fontFamily: 'Poppins, sans-serif' }}>
              StyleMuse
            </span>
          </Link>

          <div className="flex gap-2">
            <NavLink to="/home" icon={Home} label="Home" active={isActive('/home')} />
            <NavLink to="/profile" icon={User} label="Profile" active={isActive('/profile')} />
            <NavLink to="/about" icon={Info} label="About" active={isActive('/about')} />
          </div>
        </div>
      </div>
    </nav>
  );
}

function NavLink({ to, icon: Icon, label, active }: { to: string; icon: any; label: string; active: boolean }) {
  return (
    <Link
      to={to}
      className={`flex items-center gap-2 px-5 py-2 rounded-full transition-all duration-300 ${
        active
          ? 'bg-gradient-to-r from-peach-200 to-pink-200 text-gray-800 shadow-md'
          : 'text-gray-600 hover:bg-gray-50'
      }`}
    >
      <Icon className="w-4 h-4" />
      <span className="font-medium text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>{label}</span>
    </Link>
  );
}
