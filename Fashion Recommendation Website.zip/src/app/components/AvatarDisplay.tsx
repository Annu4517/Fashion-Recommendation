import { useAvatar } from '../context/AvatarContext';
import { avatarStyles } from '../data/avatarData';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Sparkles } from 'lucide-react';

export function AvatarDisplay({ size = 'large', showInfo = true }: { size?: 'small' | 'medium' | 'large'; showInfo?: boolean }) {
  const { selectedAvatar } = useAvatar();
  const avatarData = avatarStyles[selectedAvatar];

  const sizeClasses = {
    small: 'w-20 h-20',
    medium: 'w-32 h-32',
    large: 'w-48 h-48'
  };

  const borderSize = {
    small: 'border-4',
    medium: 'border-4',
    large: 'border-[6px]'
  };

  return (
    <div className="flex flex-col items-center gap-3 animate-fadeIn">
      <div className="relative">
        <div
          className={`${sizeClasses[size]} ${borderSize[size]} rounded-full overflow-hidden shadow-2xl transition-all duration-700 transform hover:scale-105`}
          style={{
            borderColor: avatarData.color,
            boxShadow: `0 10px 40px ${avatarData.color}40`
          }}
        >
          <ImageWithFallback
            src={avatarData.image}
            alt={avatarData.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div
          className="absolute -top-1 -right-1 w-8 h-8 rounded-full flex items-center justify-center shadow-lg"
          style={{ backgroundColor: avatarData.color }}
        >
          <Sparkles className="w-4 h-4 text-white" />
        </div>
      </div>

      {showInfo && (
        <div className="text-center space-y-1">
          <h3 className="font-semibold text-gray-800" style={{ fontFamily: 'Poppins, sans-serif' }}>
            {avatarData.name}
          </h3>
          <p className="text-sm text-gray-500" style={{ fontFamily: 'Inter, sans-serif' }}>
            {avatarData.description}
          </p>
        </div>
      )}
    </div>
  );
}
