
  # Fashion Recommendation Website

  This is a code bundle for Fashion Recommendation Website. The original project is available at https://www.figma.com/design/QwuqWjtALr5pvJQ2VvZZrV/Fashion-Recommendation-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  